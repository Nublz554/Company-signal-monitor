#!/usr/bin/env python3
"""backtest_score.py - does the signal score predict anything? test it honestly.

THE ONLY HONEST TEST of a scoring rule is a point-in-time backtest: compute the score using
ONLY information that was public as of each observation date, then measure what the stock
actually did over the following 90 days. No lookahead, no re-fitting the weights after
seeing the answers.

WHAT IS TESTED (and what is not, honestly):
  TESTED     filing activity   - an 8-K or 10-K/10-Q filed within 30 days  (weight 3)
  TESTED     insider activity  - 3+ Form 4s within 30 days                 (weight 3)
  TESTED     price anomaly     - last close more than 2 sigma from SMA20    (weight 1)
  NOT TESTED insider DIRECTION - buy vs sell needs Form 4 XML parsing. This backtest scores
             insider ACTIVITY, not conviction, which is a materially weaker signal. A positive
             result here does NOT validate the skill's insider-cluster rule.
  NOT TESTED news volume, 13D landings, 13F diffs, imagery, contracts. No free point-in-time
             series exists for these without heavy reconstruction.

Baseline is excess return over SPY, so a result is not just market beta.

usage:
  python backtest_score.py --out "$LOCALAPPDATA/Temp/csm-backtest" [--years 4] [--limit 40]
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

SEC_HEADERS = {"User-Agent": "CompanySignalMonitor backtest contact@example.com"}
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/131.0 Safari/537.36")

# spread across sectors so the result is not one regime's accident
UNIVERSE = [
    "AAPL", "MSFT", "GOOGL", "AMZN", "META", "NVDA", "AMD", "INTC", "ORCL", "CRM",
    "ADBE", "CSCO", "IBM", "QCOM", "TXN", "JPM", "BAC", "WFC", "GS", "MS",
    "V", "MA", "AXP", "JNJ", "PFE", "MRK", "ABBV", "UNH", "LLY", "TMO",
    "XOM", "CVX", "COP", "CAT", "DE", "HON", "GE", "BA", "LMT", "RTX",
    "WMT", "COST", "TGT", "HD", "LOW", "KO", "PEP", "PG", "MCD", "NKE",
    "TSLA", "F", "GM", "DIS", "NFLX", "T", "VZ", "PLTR", "SNOW", "UBER",
]


def get_json(url, headers=None, attempts=4, base=4.0):
    last = None
    for i in range(attempts):
        try:
            r = requests.get(url, headers=headers or {"User-Agent": BROWSER_UA}, timeout=45)
            if r.status_code in (429, 500, 502, 503, 504):
                raise RuntimeError(f"HTTP {r.status_code}")
            r.raise_for_status()
            return r.json()
        except Exception as e:  # noqa: BLE001
            last = e
            if i == attempts - 1:
                break
            time.sleep(base * (2 ** i))
    raise RuntimeError(str(last)[:120])


def price_series(ticker):
    d = get_json(f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"
                 "?range=6y&interval=1d")
    res = d["chart"]["result"][0]
    ts = res["timestamp"]
    q = res["indicators"]["quote"][0]
    out = []
    for i, c in enumerate(q["close"]):
        if c is None:
            continue
        out.append((datetime.fromtimestamp(ts[i], tz=timezone.utc).date(), float(c)))
    return out


def ticker_to_cik():
    d = get_json("https://www.sec.gov/files/company_tickers.json", headers=SEC_HEADERS)
    return {v["ticker"].upper(): str(v["cik_str"]).zfill(10) for v in d.values()}


def filing_dates(cik):
    d = get_json(f"https://data.sec.gov/submissions/CIK{cik}.json", headers=SEC_HEADERS)
    r = d.get("filings", {}).get("recent", {})
    out = []
    for i, form in enumerate(r.get("form", [])):
        dt = r["filingDate"][i]
        if dt:
            out.append((datetime.strptime(dt, "%Y-%m-%d").date(), form))
    out.sort()
    return out


def score_at(t, filings, closes, close_idx, spy_closes):
    """point-in-time score using ONLY filings dated <= t and closes up to t."""
    recent = [f for (d, f) in filings if t - timedelta(days=30) <= d <= t]
    s, detail = 0, {}
    if any(f in ("8-K", "10-K", "10-Q") for f in recent):
        s += 3
        detail["filing_30d"] = [f for f in recent if f in ("8-K", "10-K", "10-Q")]
    n4 = sum(1 for f in recent if f == "4")
    if n4 >= 3:
        s += 3
        detail["form4_30d"] = n4
    window = [c for (d, c) in closes if d <= t][-20:]
    if len(window) >= 20:
        sd = statistics.pstdev(window) or 1e-9
        z = (window[-1] - statistics.mean(window)) / sd
        if abs(z) >= 2:
            s += 1
            detail["z"] = round(z, 2)
    return s, detail


def forward_excess(closes, t, horizon_days, spy, spy_by_date):
    after = [(d, c) for (d, c) in closes if d >= t + timedelta(days=horizon_days)]
    base = [c for (d, c) in closes if d <= t]
    if not after or not base:
        return None
    try:
        spy0 = max(d for d in spy_by_date if d <= t)
        spy1 = min(d for d in spy_by_date if d >= t + timedelta(days=horizon_days))
    except ValueError:
        return None
    r = after[0][1] / base[-1] - 1
    rb = spy_by_date[spy1] / spy_by_date[spy0] - 1
    return r - rb


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--years", type=float, default=4.0)
    ap.add_argument("--limit", type=int, default=40)
    ap.add_argument("--horizon", type=int, default=90)
    ap.add_argument("--obs-days", type=int, default=30,
                    help="spacing between observations; set >= horizon for non-overlapping windows")
    a = ap.parse_args()

    out = Path(a.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)

    print("BACKTEST - point-in-time signal score vs forward excess return")
    print(f"horizon {a.horizon}d | universe {min(a.limit, len(UNIVERSE))} tickers | "
          f"baseline = excess over SPY\n")

    spy = price_series("SPY")
    spy_by_date = {d: c for d, c in spy}
    print(f"  SPY: {len(spy)} days, {spy[0][0]} -> {spy[-1][0]}")

    m = ticker_to_cik()
    cutoff = spy[-1][0] - timedelta(days=a.horizon + 5)

    rows, failures = [], []
    for tk in UNIVERSE[:a.limit]:
        cik = m.get(tk)
        if not cik:
            failures.append((tk, "no CIK"))
            continue
        try:
            fl = filing_dates(cik)
            cl = price_series(tk)
        except Exception as e:  # noqa: BLE001
            failures.append((tk, f"{type(e).__name__}: {str(e)[:60]}"))
            continue
        if len(cl) < 300:
            failures.append((tk, f"only {len(cl)} closes"))
            continue

        start = max(cl[0][0], spy[-1][0] - timedelta(days=int(365 * a.years)))
        obs = [d for (d, _) in cl if d >= start and d <= cutoff]
        per_year = max(1, int(365 / max(a.obs_days, 1)))
        step = max(1, len(obs) // int(a.years * per_year))
        obs = obs[::step]
        n = 0
        for t in obs:
            s, detail = score_at(t, fl, cl, None, None)
            fe = forward_excess(cl, t, a.horizon, spy, spy_by_date)
            if fe is None:
                continue
            rows.append({"ticker": tk, "date": str(t), "score": s,
                         "fwd_excess_90d": round(fe, 4), "detail": detail})
            n += 1
        print(f"  {tk:6} {len(fl):5} filings  {len(cl):5} closes  -> {n:3} observations")

    (out / "observations.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

    if not rows:
        print("\n  NO OBSERVATIONS - cannot conclude anything.")
        return 1

    print(f"\n{'='*62}\nRESULTS  ({len(rows)} observations, {len(set(r['ticker'] for r in rows))} tickers)")
    allf = [r["fwd_excess_90d"] for r in rows]
    base_mean = statistics.mean(allf)
    print(f"  baseline: every observation, mean excess {base_mean*100:+.2f}%  "
          f"(sd {statistics.pstdev(allf)*100:.2f}%)")

    print(f"\n  {'score':>5} {'n':>6} {'mean excess':>12} {'median':>9} {'sd':>7}  {'vs base':>9}")
    for s in sorted(set(r["score"] for r in rows)):
        sub = [r["fwd_excess_90d"] for r in rows if r["score"] == s]
        if len(sub) < 10:
            print(f"  {s:>5} {len(sub):>6}   (too few to read)")
            continue
        mean = statistics.mean(sub)
        print(f"  {s:>5} {len(sub):>6} {mean*100:>11.2f}% {statistics.median(sub)*100:>8.2f}% "
              f"{statistics.pstdev(sub)*100:>6.2f}% {(mean-base_mean)*100:>8.2f}%")

    hi = [r["fwd_excess_90d"] for r in rows if r["score"] >= 3]
    lo = [r["fwd_excess_90d"] for r in rows if r["score"] == 0]
    print(f"\n  score>=3 vs score==0:")
    if len(hi) >= 10 and len(lo) >= 10:
        mh, ml = statistics.mean(hi), statistics.mean(lo)
        se = math.sqrt(statistics.pvariance(hi)/len(hi) + statistics.pvariance(lo)/len(lo)) or 1e-9
        t = (mh - ml) / se
        print(f"    high n={len(hi)} mean {mh*100:+.2f}%   low n={len(lo)} mean {ml*100:+.2f}%")
        print(f"    difference {(mh-ml)*100:+.2f}%   t = {t:+.2f}   "
              f"{'SIGNIFICANT at ~2 sigma' if abs(t) >= 1.96 else 'NOT significant'}")
        print("    a |t| under 1.96 means the gap is indistinguishable from noise.")
    else:
        print("    too few in one bucket to test")

    print(f"\n  CAVEAT, read before believing any of this:")
    print(f"    - insider DIRECTION (buy vs sell) is NOT parsed; this scores activity only")
    print(f"    - no transaction costs, no slippage, no borrow")
    print(f"    - overlapping 90d windows mean observations are NOT independent, so the")
    print(f"      effective sample is smaller than n and t is optimistic")
    print(f"\n  observations -> {out/'observations.json'}")
    if failures:
        print(f"  failures ({len(failures)}): {failures[:8]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
