#!/usr/bin/env python3
"""site_imagery.py - dated Sentinel-2 crops of a company facility, for the SATA module.

searches the keyless Earth Search STAC API for the best scene just BEFORE and just AFTER a split
date over a site bounding box, window-reads the 'visual' (true colour) COG for that bbox only,
and writes two PNGs, a **side-by-side composite**, and a metadata JSON.

the composite is the point: comparing two images in ONE look forces relative judgement, where
describing them one at a time invites inventing a difference.

  GSD IS 10 m. a car is ~4.5 m and is therefore SUB-PIXEL. you cannot count cars and you cannot
  measure parking-lot occupancy. you CAN see building footprints appearing or vanishing,
  construction pads, demolition, lot AREA change, cranes, container yards, rail rakes, and
  building-scale damage.

usage:
  python site_imagery.py --name "Tesla Fremont" --lat 37.4927 --lon -121.9447 \
      --half-km 1.2 --split 2026-06-01 --out "$LOCALAPPDATA/Temp/csm-sata-tesla"

exit 0 = pair rendered, 2 = one date only, 3 = neither.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import requests

STAC = "https://earth-search.aws.element84.com/v1/search"
TIMEOUT = 60
MAX_CLOUD = 20.0


def bbox_from(lat: float, lon: float, half_km: float) -> tuple[float, float, float, float]:
    dlat = half_km / 111.32
    dlon = half_km / (111.32 * max(math.cos(math.radians(lat)), 1e-6))
    return (lon - dlon, lat - dlat, lon + dlon, lat + dlat)


def search(bbox, limit=200):
    body = {
        "collections": ["sentinel-2-l2a"],
        "bbox": list(bbox),
        "limit": limit,
        "query": {"eo:cloud_cover": {"lt": MAX_CLOUD}},
    }
    r = requests.post(STAC, json=body, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json().get("features", [])


def _t(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def pick_pair(features, split_date: str):
    """Closest scene to the split date on each side, cloud as the tiebreak.

    NOT the globally lowest cloud cover: that chased a 0%-cloud scene 14 months before the split
    and produced a 'change' that was mostly seasonal. For change detection, temporal proximity at
    acceptable quality beats maximum quality at any date.
    """
    split = _t(split_date if "T" in split_date else split_date + "T00:00:00+00:00")
    before, after = [], []
    for f in features:
        dt = f["properties"].get("datetime")
        cc = f["properties"].get("eo:cloud_cover")
        if not dt or cc is None or cc >= MAX_CLOUD:
            continue
        try:
            t = _t(dt)
        except ValueError:
            continue
        (before if t < split else after).append((abs((t - split).total_seconds()), cc, dt, f))
    before.sort(key=lambda x: (x[0], x[1]))
    after.sort(key=lambda x: (x[0], x[1]))
    b = (before[0][1], before[0][2], before[0][3]) if before else None
    a = (after[0][1], after[0][2], after[0][3]) if after else None
    return b, a


def render_crop(item, bbox, out_png: Path, scale: int = 3) -> dict:
    """window-read just the bbox out of the remote COG. no full-tile download."""
    import rasterio
    from rasterio.crs import CRS
    from rasterio.warp import transform_bounds
    from rasterio.windows import from_bounds
    from PIL import Image

    href = item["assets"]["visual"]["href"]
    with rasterio.open(href) as src:
        # Sentinel-2 COGs are UTM-projected; the caller's bbox is EPSG:4326. without this
        # reprojection from_bounds computes an offset thousands of pixels outside the tile
        # and every read comes back empty.
        b = transform_bounds(CRS.from_epsg(4326), src.crs, *bbox) if (
            src.crs and src.crs.to_epsg() != 4326) else bbox
        win = from_bounds(*b, transform=src.transform)
        win = win.intersection(rasterio.windows.Window(0, 0, src.width, src.height))
        if win.width < 2 or win.height < 2:
            raise RuntimeError(f"bbox does not intersect the tile (w={win.width:.1f})")
        arr = src.read(window=win)
        px = abs(src.transform.a)
    img = Image.fromarray(arr[:3].transpose(1, 2, 0).astype("uint8"), mode="RGB")
    w, h = img.size
    img = img.resize((w * scale, h * scale), Image.LANCZOS)
    img.save(out_png)
    return {"png": out_png.name, "native_pixels": f"{w}x{h}", "zoom": f"{scale}x",
            "gsd_m": round(px, 1), "ground_width_m": round(w * px)}


def make_composite(before_png: Path, after_png: Path, out_png: Path) -> Path:
    """before | after in one frame, with a red divider. one look, one comparison."""
    from PIL import Image

    a, b = Image.open(before_png).convert("RGB"), Image.open(after_png).convert("RGB")
    h = max(a.height, b.height)
    gap = 10
    canvas = Image.new("RGB", (a.width + gap + b.width, h), (220, 20, 20))
    canvas.paste(a, (0, 0))
    canvas.paste(b, (a.width + gap, 0))
    canvas.save(out_png)
    return out_png


def main() -> int:
    ap = argparse.ArgumentParser(description="dated Sentinel-2 crops of a facility")
    ap.add_argument("--name", required=True)
    ap.add_argument("--lat", type=float, required=True)
    ap.add_argument("--lon", type=float, required=True)
    ap.add_argument("--half-km", type=float, default=1.0, help="half-width of the crop, km")
    ap.add_argument("--split", required=True, help="YYYY-MM-DD boundary between before/after")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    out = Path(a.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    bbox = bbox_from(a.lat, a.lon, a.half_km)
    print(f"SITE IMAGERY -> {out}")
    print(f"site: {a.name}   bbox: {[round(x, 5) for x in bbox]}")
    print(f"split: {a.split}   crop: {a.half_km * 2:.1f} km across   pixels are 10 m")

    feats = search(bbox)
    print(f"  {len(feats)} scenes under {MAX_CLOUD:.0f}% cloud")
    b, af = pick_pair(feats, a.split)

    meta = {"site": a.name, "lat": a.lat, "lon": a.lon, "bbox": list(bbox), "split": a.split,
            "gsd_m": 10, "scenes_considered": len(feats), "rendered": {},
            "resolution_limit": ("10 m GSD: cars are sub-pixel. lot OCCUPANCY cannot be measured. "
                                 "footprints, pads, demolition, lot AREA, cranes, damage only.")}

    rendered, paths = 0, {}
    for label, pick in (("before", b), ("after", af)):
        if pick is None:
            print(f"  [{label:6}] no scene on that side of the split")
            meta["rendered"][label] = None
            continue
        cc, dt, item = pick
        png = out / f"{label}.png"
        try:
            info = render_crop(item, bbox, png)
        except Exception as e:  # noqa: BLE001
            print(f"  [{label:6}] RENDER FAILED: {type(e).__name__}: {str(e)[:80]}")
            meta["rendered"][label] = {"error": str(e)[:160]}
            continue
        info.update({"scene_id": item["id"], "acquired": dt, "cloud_cover_pct": round(cc, 2)})
        meta["rendered"][label] = info
        paths[label] = png
        rendered += 1
        print(f"  [{label:6}] {dt[:10]}   cloud {cc:5.2f}%   -> {png}")

    if rendered == 2:
        comp = make_composite(paths["before"], paths["after"], out / "composite.png")
        days = abs((_t(meta["rendered"]["after"]["acquired"]) -
                    _t(meta["rendered"]["before"]["acquired"])).days)
        meta["gap_days"] = days
        meta["composite"] = comp.name
        print(f"\n  ONE LOOK, ONE COMPARISON  ({days} days apart):")
        print(f"    {comp}")
        print(f"      left  = {meta['rendered']['before']['acquired'][:10]}")
        print(f"      right = {meta['rendered']['after']['acquired'][:10]}")
        print("\n  a gap over ~400 days is seasonal, not a clean comparison - say so.")
    (out / "site_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"  meta -> {out / 'site_meta.json'}")
    if rendered < 2:
        print(f"\n  only {rendered}/2 rendered - record as a GAP. do not narrate a change.")
    return 0 if rendered == 2 else (2 if rendered == 1 else 3)


if __name__ == "__main__":
    sys.exit(main())
