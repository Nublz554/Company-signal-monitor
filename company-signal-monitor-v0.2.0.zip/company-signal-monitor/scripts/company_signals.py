#!/usr/bin/env python3
"""company_signals.py - local bulk fetcher for COMPANY SIGNAL MONITOR.

does every heavy HTTP call in ONE local process so no model tokens are spent on fetching.
writes one JSON per source plus summary.json into --out.

every source is free and keyless:
  sec_submissions  data.sec.gov/submissions/CIK##########.json
  sec_fulltext     efts.sec.gov/LATEST/search-index?q=...
  gdelt_volume     api.gdeltproject.org/api/v2/doc/doc  mode=timelinevol
  gdelt_articles   api.gdeltproject.org/api/v2/doc/doc  mode=artlist
  news_rss         news.google.com/rss/search
  market           query1.finance.yahoo.com/v8/finance/chart/<ticker>
  contracts        api.usaspending.gov/api/v2/search/spending_by_award/

usage:
  python company_signals.py --name "Apple Inc." --cik 0000320193 --ticker AAPL \
      --domain apple.com --contact you@yourdomain --out "$LOCALAPPDATA/Temp/csm-apple"

exit 0 = every source ok, 2 = at least one gap (gaps are recorded, never silently dropped).
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import requests

TIMEOUT = 30
RETRY_CODES = {429, 500, 502, 503, 504}
BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0 Safari/537.36"
)

results: dict[str, str] = {}


def record(source: str, status: str, note: str = "") -> None:
    results[source] = status if not note else f"{status} ({note})"
    print(f"  [{status:7}] {source} {note}")


def save(out: Path, name: str, payload) -> None:
    (out / f"{name}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def request_json(url, *, method="GET", headers=None, payload=None, attempts=4, base_delay=5.0):
    """GET/POST returning parsed JSON, retrying 429/5xx with exponential backoff.

    429 and 503 are the observed failures on this host (GDELT and USAspending); they are
    transient and must not be recorded as a source gap on the first attempt.
    """
    hdrs = headers or {"User-Agent": BROWSER_UA}
    last = None
    for i in range(attempts):
        try:
            if method == "POST":
                r = requests.post(url, json=payload, headers=hdrs, timeout=TIMEOUT)
            else:
                r = requests.get(url, headers=hdrs, timeout=TIMEOUT)
            if r.status_code in RETRY_CODES:
                raise RuntimeError(f"HTTP {r.status_code}")
            r.raise_for_status()
            return r.json()
        except Exception as e:  # noqa: BLE001 - any transport failure is retryable here
            last = e
            if i == attempts - 1:
                break
            delay = base_delay * (2 ** i)
            print(f"        retry {i + 1}/{attempts - 1} in {delay:.0f}s  ({str(e)[:70]})")
            time.sleep(delay)
    raise RuntimeError(f"gave up after {attempts} attempts: {last}")


def request_text(url, *, headers=None, attempts=4, base_delay=5.0) -> str:
    hdrs = headers or {"User-Agent": BROWSER_UA}
    last = None
    for i in range(attempts):
        try:
            r = requests.get(url, headers=hdrs, timeout=TIMEOUT)
            if r.status_code in RETRY_CODES:
                raise RuntimeError(f"HTTP {r.status_code}")
            r.raise_for_status()
            return r.text
        except Exception as e:  # noqa: BLE001
            last = e
            if i == attempts - 1:
                break
            delay = base_delay * (2 ** i)
            print(f"        retry {i + 1}/{attempts - 1} in {delay:.0f}s  ({str(e)[:70]})")
            time.sleep(delay)
    raise RuntimeError(f"gave up after {attempts} attempts: {last}")


# ------------------------------------------------------------------ SEC EDGAR
def sec_headers(contact: str) -> dict:
    return {"User-Agent": f"CompanySignalMonitor {contact}"}


def fetch_sec_submissions(cik: str, out: Path, contact: str) -> None:
    cik = cik.zfill(10)
    d = request_json(
        f"https://data.sec.gov/submissions/CIK{cik}.json", headers=sec_headers(contact)
    )
    recent = d.get("filings", {}).get("recent", {})
    keys = ["form", "filingDate", "reportDate", "accessionNumber", "primaryDocument", "items"]
    n = len(recent.get("form", []))
    rows = [{k: recent.get(k, [""] * n)[i] for k in keys} for i in range(n)]
    rows = [r for r in rows if r["form"]][:200]
    save(out, "sec_submissions", {
        "cik": cik, "name": d.get("name"), "sic": d.get("sicDescription"),
        "tickers": d.get("tickers", []), "filings_last200": rows,
    })
    window = {"8-K", "10-K", "10-Q", "4", "S-1", "8-A", "13D", "SC 13D"}
    notable = [r for r in rows if r["form"] in window][:40]
    save(out, "sec_notable", notable)
    record("sec_submissions", "ok", f"{len(rows)} filings, {len(notable)} notable")


def fetch_sec_fulltext(name: str, out: Path, contact: str) -> None:
    q = urllib.parse.quote_plus(f'"{name}"')
    d = request_json(
        f"https://efts.sec.gov/LATEST/search-index?q={q}", headers=sec_headers(contact)
    )
    hits = d.get("hits", {})
    total = hits.get("total", {})
    sample = []
    for h in hits.get("hits", [])[:25]:
        src = h.get("_source", {})
        sample.append({"form": src.get("file_type"), "date": src.get("file_date"),
                       "names": src.get("display_names"), "id": h.get("_id")})
    save(out, "sec_fulltext", {
        "query": name, "total_relation": total.get("relation"),
        "total_value": total.get("value"), "sample": sample,
    })
    record("sec_fulltext", "ok", f"{total.get('value')} ({total.get('relation')})")


# --------------------------------------------------------------------- GDELT
def fetch_gdelt(name: str, out: Path) -> None:
    """GDELT allows ONE request per 5 seconds; bursts return HTML instead of JSON."""
    q = urllib.parse.quote_plus(f'"{name}"')
    time.sleep(5.5)
    vol = request_json(
        "https://api.gdeltproject.org/api/v2/doc/doc"
        f"?query={q}&mode=timelinevol&format=json&timespan=3m",
        attempts=5, base_delay=8.0,
    )
    series = [
        {"date": pt.get("date"), "value": pt.get("value")}
        for s in vol.get("timeline", []) for pt in s.get("data", [])
    ]
    vals = [p["value"] for p in series if p["value"] is not None]
    stats = {}
    if len(vals) >= 10:
        tail, base = vals[-3:], vals[:-3]
        mu = statistics.mean(base)
        sd = statistics.pstdev(base) or 1e-9
        stats = {
            "n_days": len(vals), "mean": round(mu, 6), "stdev": round(sd, 6),
            "recent3_mean": round(statistics.mean(tail), 6),
            "zscore_recent3": round((statistics.mean(tail) - mu) / sd, 3),
        }
    save(out, "gdelt_volume", {"series": series, "stats": stats})
    z = stats.get("zscore_recent3")
    flag = " ABNORMAL ATTENTION" if z is not None and abs(z) > 2 else ""
    record("gdelt_volume", "ok", f"{len(series)} days, z={z}{flag}")

    time.sleep(5.5)
    art = request_json(
        "https://api.gdeltproject.org/api/v2/doc/doc"
        f"?query={q}&mode=artlist&maxrecords=25&format=json&timespan=3d&sort=hybridrel",
        attempts=5, base_delay=8.0,
    )
    articles = [
        {"title": a.get("title"), "url": a.get("url"), "domain": a.get("domain"),
         "seendate": a.get("seendate"), "language": a.get("language")}
        for a in art.get("articles", [])
    ]
    save(out, "gdelt_articles", articles)
    record("gdelt_articles", "ok", f"{len(articles)} articles")


# ------------------------------------------------------------------ News RSS
def fetch_rss(name: str, out: Path) -> None:
    # spaces MUST be '+', not '%20': %20 returns 0 items on this host (measured).
    q = urllib.parse.quote_plus(f'"{name}"')
    xml = request_text(
        f"https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en"
    )
    root = ET.fromstring(xml)
    items = []
    for it in root.iter("item"):
        src = it.find("source")
        items.append({
            "title": (it.findtext("title") or "").strip(),
            "link": (it.findtext("link") or "").strip(),
            "pubDate": (it.findtext("pubDate") or "").strip(),
            "source": (src.text if src is not None else ""),
        })
    save(out, "news_rss", items[:40])
    record("news_rss", "ok", f"{len(items)} items")


# --------------------------------------------------------------------- TAPE
def fetch_market(ticker: str, out: Path) -> None:
    d = request_json(
        f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(ticker)}"
        "?range=1y&interval=1d"
    )
    res = d["chart"]["result"][0]
    ts = res.get("timestamp", [])
    quote = res.get("indicators", {}).get("quote", [{}])[0]
    closes_raw = quote.get("close", [])
    vols_raw = quote.get("volume") or [None] * len(closes_raw)

    closes, vols, dates = [], [], []
    for i, c in enumerate(closes_raw):  # nulls = market closed / missing data
        if c is None:
            continue
        closes.append(float(c))
        vols.append(float(vols_raw[i]) if i < len(vols_raw) and vols_raw[i] else 0.0)
        dates.append(datetime.fromtimestamp(ts[i], tz=timezone.utc).strftime("%Y-%m-%d"))
    if len(closes) < 30:
        raise RuntimeError(f"only {len(closes)} usable closes")

    def ret(n: int):
        return round(closes[-1] / closes[-n] - 1, 4) if len(closes) > n else None

    def sma(n: int):
        return round(sum(closes[-n:]) / n, 2) if len(closes) >= n else None

    logs = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes)) if closes[i - 1] > 0]
    vol30 = round(statistics.pstdev(logs[-30:]) * math.sqrt(252), 4) if len(logs) >= 30 else None
    last20 = closes[-20:]
    sd20 = statistics.pstdev(last20) or 1e-9
    z = round((closes[-1] - statistics.mean(last20)) / sd20, 2)
    lo, hi = min(closes), max(closes)
    s = {
        "ticker": ticker, "last_date": dates[-1], "last_close": round(closes[-1], 2),
        "return_5d": ret(5), "return_30d": ret(30), "return_1y": ret(252),
        "sma20": sma(20), "sma50": sma(50),
        "trend": ("up" if (sma(20) and sma(50) and closes[-1] > sma(20) > sma(50))
                  else "down" if (sma(20) and sma(50) and closes[-1] < sma(20) < sma(50))
                  else "mixed"),
        "realized_vol_30d_annualized": vol30,
        "zscore_vs_sma20": z,
        "avg_volume_30d": round(sum(vols[-30:]) / 30) if len(vols) >= 30 else None,
        "position_52w": round((closes[-1] - lo) / ((hi - lo) or 1e-9), 3),
        "note": "descriptive statistics only - not a forecast",
    }
    save(out, "market", {"summary": s, "closes": closes[-260:], "dates": dates[-260:]})
    flag = " UNUSUAL MOVE" if abs(z) >= 2 else ""
    record("market", "ok", f"{ticker} {s['last_close']} z={z}{flag}")


# ------------------------------------------------------------------- LEDGER
def fetch_contracts(name: str, out: Path) -> None:
    payload = {
        "filters": {"keywords": [name], "award_type_codes": ["A", "B", "C", "D"]},
        "fields": ["Award ID", "Recipient Name", "Award Amount", "Awarding Agency",
                   "Start Date", "Description"],
        "limit": 25, "page": 1, "sort": "Award Amount", "order": "desc",
    }
    d = request_json(
        "https://api.usaspending.gov/api/v2/search/spending_by_award/",
        method="POST", payload=payload, headers={"User-Agent": BROWSER_UA,
                                                 "Content-Type": "application/json"},
        attempts=5, base_delay=5.0,
    )
    rows = d.get("results", [])
    save(out, "contracts", rows)
    total = sum(float(x.get("Award Amount") or 0) for x in rows)
    record("contracts", "ok", f"{len(rows)} awards, ${total / 1e6:.1f}M in top 25")


# --------------------------------------------------------------------- main
def run(a) -> int:
    out = Path(a.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    print(f"COMPANY SIGNAL MONITOR fetch -> {out}")
    print(f"subject: {a.name}" + (f"  (CIK {a.cik})" if a.cik else ""))

    steps = []
    if a.cik:
        steps.append(("sec_submissions", lambda: fetch_sec_submissions(a.cik, out, a.contact)))
    steps.append(("sec_fulltext", lambda: fetch_sec_fulltext(a.name, out, a.contact)))
    steps.append(("gdelt", lambda: fetch_gdelt(a.name, out)))
    steps.append(("news_rss", lambda: fetch_rss(a.name, out)))
    if a.ticker:
        steps.append(("market", lambda: fetch_market(a.ticker, out)))
    steps.append(("contracts", lambda: fetch_contracts(a.name, out)))

    for label, fn in steps:
        try:
            fn()
        except Exception as e:  # noqa: BLE001 - a failed source is a GAP, never "no news"
            record(label, "FAILED", f"{type(e).__name__}: {str(e)[:90]}")

    gaps = [k for k, v in results.items() if v.startswith("FAILED")]
    save(out, "summary", {
        "subject": a.name, "cik": a.cik, "ticker": a.ticker, "domain": a.domain,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sources": results, "gaps": gaps,
        "note": "a failed source means UNKNOWN COVERAGE, not 'no news'.",
        "artifacts": sorted(p.name for p in out.glob("*.json")),
    })
    print(f"\n{len(results) - len(gaps)}/{len(results)} sources ok; gaps: {gaps or 'none'}")
    print(f"summary -> {out / 'summary.json'}")
    return 0 if not gaps else 2


def main() -> int:
    ap = argparse.ArgumentParser(description="company signal bulk fetcher")
    ap.add_argument("--name", required=True, help="legal company name")
    ap.add_argument("--cik", help="SEC CIK (zero-padded automatically)")
    ap.add_argument("--ticker", help="stock ticker, public companies only")
    ap.add_argument("--domain", help="company domain")
    ap.add_argument("--contact", default="research@example.com",
                    help="contact address for the SEC User-Agent (SEC requires this)")
    ap.add_argument("--out", required=True, help="output directory for artifacts")
    return run(ap.parse_args())


if __name__ == "__main__":
    sys.exit(main())
