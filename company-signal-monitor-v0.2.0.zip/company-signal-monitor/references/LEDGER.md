# LEDGER.md — federal awards (USAspending)

the most under-used free company source there is. contract wins and losses are hard revenue signals,
publicly filed, and almost nobody bothers to look.

## SOURCE

POST to `https://api.usaspending.gov/api/v2/search/spending_by_award/` — no key.

```
curl -s -X POST "https://api.usaspending.gov/api/v2/search/spending_by_award/" \
  -H "Content-Type: application/json" \
  -d '{"filters":{"keywords":["<company name>"],"award_type_codes":["A","B","C","D"]},
       "fields":["Award ID","Recipient Name","Award Amount","Awarding Agency","Start Date","Description"],
       "limit":25,"page":1,"sort":"Award Amount","order":"desc"}'
```

award type codes: `A`/`B`/`C`/`D` are contracts (BPA, purchase order, delivery, definitive). `IDV_*`
are vehicles. add `"05"`,`"06"` for grants when the company is a non-profit or a research shop.

the API 503s intermittently. the fetcher retries with backoff — a 503 is a gap only after the
retries are spent.

## WHAT TO PULL

- **new awards** in the last 90 days — recipient, agency, amount, description
- **concentration** — what share of recent value comes from a single agency? one agency above ~70% of
  value is a dependency finding
- **trajectory** — obligated value this 90d against the prior 90d
- **loss signal** — a recurring program's award going to a competitor. requires searching the
  *program* keywords, not just the company name

amounts are `MEASURED` class. these are filed figures, not estimates.

## DONE WHEN

- every award over $1M in the last 90 days listed, with agency and description
- 90d vs prior-90d obligated total computed, direction stated
- recipient matching accounts for subsidiaries (a parent's award is often filed under a
  subsidiary's legal name) — name which strings were searched

## PITFALLS

- keyword search matches on **name only**. `"Lockheed Martin Corporation"` and
  `"Lockheed Martin Corp"` are different buckets. search both, plus known subsidiaries.
- `Recipient Name` matching is fuzzy on purpose. a similarly-named hit is not evidence of a contract.
  confirm on exactness plus agency plus description.
- amounts are **obligated**, not the total contract ceiling. an IDV with a $5B ceiling may have $0
  obligated. always say which one you are reporting.
- the API is slow across wide date ranges. keep `limit` modest and page deliberately.
- no results for a private company is normal — most do not contract with the federal government.
  that is a finding about coverage, not a finding of no revenue.
