# FILINGS.md — SEC EDGAR

the company's own words, filed under legal penalty for lying. everything else is commentary on this.
free, keyless, no rate limit worth respecting at this scale.

## SOURCES

| what | where |
|---|---|
| company + filing index | `https://data.sec.gov/submissions/CIK##########.json` (CIK zero-padded to 10) |
| XBRL financial facts | `https://data.sec.gov/api/xbrl/companyconcept/CIK##########/us-gaap/<Tag>.json` |
| full-text search, all filings | `https://efts.sec.gov/LATEST/search-index?q=<terms>` |
| the filing itself | `https://www.sec.gov/Archives/edgar/data/<cik>/<accession-no-dashes>/` |

header on **every** request or you get 403:

```
curl -s -H "User-Agent: Company Signal Monitor <contact-email>" "<url>"
```

## WHAT TO PULL

from `submissions/*.json` → `filings.recent`, walk the parallel arrays (`form`, `filingDate`,
`accessionNumber`, `primaryDocument`, `items`, `reportDate`). last **30 days**:

- **8-K** — something material happened. read `items` and NAME the event. never just report "8-K filed":
  - `2.02` earnings · `5.02` officer or director in, out · `1.01` material agreement
  - `2.05` restructuring · `4.02` non-reliance on prior financials · `7.01` Reg FD disclosure
- **10-K / 10-Q** — annual and quarterly. compare against the same period last year. direction beats
  magnitude.
- **Form 4** — insider buys and sells. three or more insiders selling in one 30-day window is a
  signal and worth one finding. one sale is noise.
- **S-1 / 8-A / 13D / SC 13D** — new registrations, listings, and anyone crossing 5% ownership.

from XBRL `companyconcept`: use real tags — `Revenues`,
`RevenueFromContractWithCustomerExcludingAssessedTax`, `NetIncomeLoss`, `OperatingIncomeLoss`,
`CashAndCashEquivalentsAtCarryingValue`. read `units.USD[]`, take the four most recent `end` dates.
if the tag 404s the company does not report it under that name — try the next tag, then record the gap.

## DONE WHEN

- every filing inside 30 days is reported as a finding or explicitly folded in as routine
- every 8-K has its `items` decoded into a named event
- direction (up / down / flat) stated for revenue and net income, with source dates
- nothing about individuals beyond their named filing role

## PITFALLS

- a 403 means your User-Agent was bad — not that the company has no filings.
- CIK must be zero-padded: `320193` → `0000320193`. unpadded is a 404.
- `efts.sec.gov` returns `hits.total.relation: "gte"` and caps at 10000. it is "at least," never an
  exact count.
- Form 4s name individuals. report the **transaction**, never assemble a picture of the person.
- do not infer financials from press coverage when the primary filing is sitting right there.
