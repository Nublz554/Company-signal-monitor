# NOISE.md — GDELT + news feeds

two jobs: **volume** (abnormal attention) and **the actual headlines with links**. GDELT gives the
time series and the ranking. Google News RSS gives you something readable to attach to it.

## SOURCES

**GDELT — volume series, 3 months, daily:**

```
curl -s "https://api.gdeltproject.org/api/v2/doc/doc?query=%22Apple+Inc.%22&mode=timelinevol&format=json&timespan=3m"
```

**GDELT — article list, last 3 days, ranked:**

```
curl -s "https://api.gdeltproject.org/api/v2/doc/doc?query=%22Apple+Inc.%22&mode=artlist&maxrecords=25&format=json&timespan=3d&sort=hybridrel"
```

**Google News RSS:**

```
curl -s -A "Mozilla/5.0" "https://news.google.com/rss/search?q=%22Apple+Inc.%22&hl=en-US&gl=US&ceid=US:en"
```

**encode spaces as `+`, NOT `%20`.** measured on this host: `%22Apple%20Inc.%22` returns **0 items**;
`%22Apple+Inc.%22` returns items. the fetcher uses `quote_plus` for exactly this reason. keep queries
tight — exact phrase in quotes plus at most one qualifier.

## WHAT TO PULL

from the timeline: the daily `value` array. compute the **z-score of the last 3 days against the
trailing 90**. `|z| > 2` is abnormal attention — report which direction.

from the article list: for each item take `title`, `domain`, `seendate` (`20260930T184500Z`), `url`.
rank by **domain quality**, not GDELT's order: primary wire and financial press > aggregators >
content farms > unknown blogs.

from RSS: the `<item>` elements — `title`, `link`, `pubDate`, `source`.

**then classify every headline:** earnings · executive change · legal/regulatory · product ·
macro/geopolitical · layoffs · M&A · other. the category tally tells a story raw volume cannot.

## DONE WHEN

- volume z-score reported, with its window and its direction
- every quoted headline has a resolvable URL and a `seendate` or `pubDate`
- category tally across the last 3 days
- syndicated duplicates collapsed into single events

## PUBLIC APPEARANCE — reputation is a P&L line

a company's public standing is not decoration; it is demand. boycotts, executive scandals, recalls,
regulatory shaming and viral service failures all hit revenue, and they hit *attention* first.

what is actually measurable, free, and keyless:

| signal | source | read |
|---|---|---|
| news volume z-score | GDELT `timelinevol` | attention spiking |
| **category mix shift** | GDELT `artlist` classification | volume moving into legal/regulatory/incident is the real signal |
| **Wikipedia pageview velocity** | `https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia/all-access/user/<Title>/daily/<start>/<end>` | public interest, keyless, no rate limit worth worrying about |
| article edit churn | MediaWiki API `rcstart`/`rvdiffto` | a controversy section growing is a slow signal |

pageviews is the under-used one: it measures public curiosity about the company directly, daily,
with a long history, and nobody checks it.

**the signal is the change in the MIX, not the volume.** steady coverage of a product launch and
steady coverage of a lawsuit are the same volume and opposite meanings. always classify, then count.

## PITFALLS

- **one GDELT request per 5 seconds.** faster returns an HTML page. the fetcher sleeps 5.5s and
  backs off on 429 — do not add parallel GDELT calls.
- `timelinetone` is a separate request. budget it like any other.
- GDELT indexes worldwide. a spike can be foreign-language coverage — check `language` before
  calling it market-relevant.
- **a volume spike is ATTENTION, not sentiment.** never report volume as if it were bad news.
- Google News RSS is an aggregator, not a primary source. find the story, then cite the outlet.
  **A `news.google.com/rss/articles/CBMi...` redirect is NOT a citation.** A child running this
  module in testing returned six findings citing those redirect URLs — they resolve, they look like
  links, and they violate this rule. Open the redirect, take the outlet's own URL, cite that. If you
  cannot resolve it, label the finding CLAIMED from the headline alone and say the article was not read.
- do not put headline quotes in `evidence` as though the article was read. load the URL or label it
  CLAIMED from the headline alone.
