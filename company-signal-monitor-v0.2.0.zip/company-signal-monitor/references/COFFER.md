# COFFER.md — where the money goes, and where it has been

two questions: **where does the money go now**, and **what has this company bought and sold before**.
the income statement is opinion. the cash flow statement is closer to fact.

## SOURCE — use `companyfacts`, not `companyconcept`

`companyconcept` gives you ONE tag. `companyfacts` gives you **every tag the company has ever filed**,
with full history. measured on Apple: 514 tags, `NetIncomeLoss` back to 2007 with 341 datapoints.

```
curl -s -H "User-Agent: CompanySignalMonitor <contact>" \
  "https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json"
```

walk `facts['us-gaap']` (and `facts['dei']`). every tag is `{'units': {'USD': [{start,end,val,form,fy,fp,...}]}}`.

**tag names differ per company.** `Revenues` is deprecated at many filers; they use
`RevenueFromContractWithCustomerExcludingAssessedTax` or `RevenueFromContractWithCustomerIncludingAssessedTax`.
search the tag list for a substring before assuming absence — a missing tag is usually a naming
difference, not an untagged fact.

## WHAT TO PULL

| question | tag |
|---|---|
| does the business generate cash | `NetCashProvidedByUsedInOperatingActivities` |
| is it investing or harvesting | `PaymentsToAcquirePropertyPlantAndEquipment` |
| is it buying itself | `PaymentsForRepurchaseOfCommonStock` |
| is it paying owners | `PaymentsOfDividends` |
| is it buying others | `PaymentsToAcquireBusinessesNetOfCashAcquired` |
| what is it sitting on | `CashAndCashEquivalentsAtCarryingValue` |
| what does it owe | `LongTermDebtNoncurrent`, `LongTermDebtCurrent` |
| what is it owed | `AccountsReceivableNetCurrent` |
| what is on the shelf | `InventoryNet` |
| what is prepaid to it | `ContractWithCustomerLiabilityCurrent` |

## THE FOUR MONEY TELLS

1. **Accrual vs cash.** `NetIncomeLoss` minus operating cash flow, as a ratio over several years. When
   reported profit persistently outruns collected cash, the earnings are lower quality than they look.
2. **Buybacks announced vs executed.** Cross the announcement (8-K or press release) against
   `PaymentsForRepurchaseOfCommonStock`. Announcing ten billion and executing two is common, and the
   gap is the finding.
3. **Receivables and inventory vs revenue.** Receivables growing faster than revenue = booking sales
   not collecting them. Inventory growing faster than revenue = goods stacking up. Both computed as
   multi-year trend, never a single quarter.
4. **Deferred revenue direction.** `ContractWithCustomerLiabilityCurrent` falling, in a subscription
   or contract business, means forward demand weakening before it shows in revenue.

## PREVIOUS TRANSACTIONS — the deal history

a company's acquisition history explains its current segments, its debt, and its write-offs. build a
timeline from filings, not from press:

| form | what it is |
|---|---|
| **8-K item 2.01** | completion of an acquisition or disposition — the event |
| **8-K item 1.01** | the material agreement that precedes it |
| **S-4** | registration of securities issued in a merger — contains the deal terms |
| **DEFM14A** | proxy for a merger vote — the fullest narrative of a deal |
| **425** | merger communications — the running story |
| **SC TO-T / SC TO-I** | third-party / issuer tender offers |
| **SC 13E3** | going-private transaction |
| **10-K Exhibit 21** | the current subsidiary list (see OWNERSHIP.md) |

Timeline columns: date, target or disposed asset, consideration (cash/stock/assumed debt), value,
form filed. Search EDGAR full-text for the subject's name plus `merger`, `acquire`, `Acquisition`.

## DONE WHEN

- a multi-year cash flow series pulled, with the tag names used recorded
- all four money tells computed or explicitly marked as not applicable, with the reason
- deal timeline built with form references, or an explicit gap
- buyback announced vs executed compared where a buyback exists
- no figure quoted without its tag name and period

## PITFALLS

- **duration vs instant facts.** `start`/`end` facts are periods (income, cash flow); `end`-only facts
  are instants (balance sheet). mixing them silently corrupts any series.
- **quarterly filings repeat the annual figure.** the same `val` appears in the 10-K, the Q4 10-Q and
  the annual frame. dedupe on `(start, end, val)` or your 10-year chart will double-count.
- **restatements rewrite history.** `fy`/`fp`/`form` change for the same period. prefer the latest
  filing's value for a given period.
- **frame tags.** `frame` entries are SEC-computed annual/quarterly windows; convenient, but they lag
  and can be absent for unusual fiscal years.
- **a deal announced is not a deal closed.** 8-K 1.01 is an agreement; 2.01 is completion. never
  report one as the other.
- **XBRL `Revenues` going stale.** Apple's `Revenues` stops in 2018 because the tag was replaced. a
  naive pull reports "revenue stopped in 2018" — a confidently wrong claim from a naming change.
  **The inverse error is worse and it happened in testing.** A child concluded Tesla's `Revenues` was
  unusable and substituted `AdvertisingRevenueCost` — a tag that last fired in 2017 — then filed the
  substitution as a gap. Tesla's `Revenues` is in fact current (`n=286`, ending 2026-09-30) and agrees
  exactly with `RevenueFromContractWithCustomerExcludingAssessedTax`. **Search the tag list for the
  term and print the last value and date before declaring a tag dead** — a wrong substitute is a
  fabricated number with a confident label.
- **The duplicate-end-date trap, concretely.** Tesla's `Revenues` series ends
  `(2026-06-30, 28,236,000,000)`, `(2026-09-30, 78,669,000,000)`, `(2026-09-30, 28,046,000,000)`. Two
  different values share one `end` date because one is a quarterly period and one is a year-to-date
  period. Taking `[-1]` gets the right number here **by luck**. Always disambiguate on the `start`
  date and the `form`, never on position.
