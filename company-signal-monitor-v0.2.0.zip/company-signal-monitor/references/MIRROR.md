# MIRROR.md — brand impersonation (sherlock)

the **only** identity-enumeration module, and it runs against the **client company's own brand
strings** — its handle, its service accounts, its product names. it answers exactly one question:
*is someone wearing this company's face?*

that question is brand protection. it is also the whole boundary of this module.

## THE LINE — narrow, and enforced

- inputs are **company identifiers only**: `@<company>`, `@<company>support`, `@<company>_help`,
  product names, and typosquat shapes (`rn` for `m`, doubled letters, dropped vowels).
- **never** run this against an individual's name, handle, or any private person's identifier. if a
  task asks for that, return `coverage: failed` with the out-of-scope gap and stop.
- do not follow a found account to its owner. report that the account exists and why it reads as
  impersonation. identifying a person is out of scope **even when the account is fake.**

## INSTALL

```
sherlock --version || pip install sherlock-project
```

not installed by default on this host. ask before installing; MIRROR is optional and the rest of the
fan-out does not depend on it.

## RUN

```
sherlock --print-found --no-color "<brand-string>" --timeout 90 --folderoutput "<workspace>"
```

bulk runs: loop the brand strings with a delay between calls, one output directory. aggressive
parallel runs get rate-limited and produce **false negatives**, which is worse than a gap.

**CAP THE RUN — measured.** A child running this module across five brand strings took **564 seconds**
and hit a kernel timeout, finishing only two of five. Cap the string list at **3-4 strings**, pass
`--timeout 60`, and treat a timeout as a `gap`. A complete sweep of everything is not worth an
incomplete sweep of anything.

**URL status is not evidence.** In the same run, both reported hits returned HTTP 200 — but a blogspot
URL returns 200 for a blank template and TikTok returns 200 with a JS shell for *any* handle. A live
URL proves the URL resolves, nothing more. Either read the page content and quote it, or report the
handle as registered-but-unverified.

## WHAT COUNTS AS A FINDING

- an account using the brand string on a platform where the company has **no registered account**
- a near-miss handle (`app1e`, `arnazon`) that is *registered*, not merely available
- a pattern across platforms — the same handle registered on 5+ sites in one sitting is automation,
  not a fan

**availability is not impersonation.** an unregistered handle means the name is free. that is a
name-squatting opportunity, not an active threat, and it ranks below an account that is actually
posting.

## DONE WHEN

- every searched brand string listed with its result count
- each candidate classified: registered-and-active / registered-and-dormant / available / not-found
- recommended action per candidate — report, monitor, or nothing
- zero person-identifying output anywhere in the findings

## PITFALLS

- false positives: some sites return "found" for any string because of their response structure.
  spot-check the two most alarming hits by hand before reporting them.
- `--nsfw` is never appropriate for a brand sweep. leave it off.
- the tool writes `<username>.txt` into the working directory — set `--folderoutput` so artifacts land
  in the workspace and not wherever the child happened to be standing.
- **absence is weak.** a brand string finding nothing means the sweep was narrow, not that the brand
  is safe.
