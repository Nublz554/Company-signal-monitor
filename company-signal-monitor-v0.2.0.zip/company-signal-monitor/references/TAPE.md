# TAPE.md — price behaviour

what the market has already priced in. **descriptive statistics only.** this module does not
predict returns and must never claim to.

## SOURCE

```
curl -s -A "Mozilla/5.0" "https://query1.finance.yahoo.com/v8/finance/chart/AAPL?range=1y&interval=1d"
```

shape: `chart.result[0].timestamp[]` (epoch seconds) plus `chart.result[0].indicators.quote[0].close[]`
and `.volume[]`. **nulls appear** where the market was closed or data is missing — filter `None`
before any arithmetic or you will crash on a holiday.

`stooq.com` is behind a JavaScript proof-of-work challenge on this host and is unusable. Yahoo works.
use Yahoo.

## WHAT TO COMPUTE

| metric | definition |
|---|---|
| 5d / 30d / 1y return | `(last / close_n) - 1` |
| SMA20 / SMA50 | mean of last 20 / 50 closes |
| trend | last close vs SMA20 vs SMA50 (above both = up) |
| realized vol 30d | stdev of daily log returns x sqrt(252) |
| move significance | `(last - SMA20) / stdev(last 20)` — an in-sample z-score |
| 52w position | `(last - min) / (max - min)` over the year |

## WHAT IT MEANS — AND WHAT IT DOES NOT

- a z beyond ±2 says **the move is unusual for THIS name.** it does not say the move continues.
- volume expansion *with* a move is conviction. a move on thin volume is drift.
- a stock can sit flat while the news is material. report the divergence — do not assume the market
  is right.
- **one name is not a market.** if a sector read is wanted, say so and compare peers. single-stock
  volatility is dominated by idiosyncratic noise.

## DONE WHEN

- returns, vol, and SMA position reported, with the date of the last close
- any ±2 z-score move flagged with magnitude and direction
- every figure traceable to the JSON — nothing recalled from memory
- the word "prediction" appears nowhere in the output

## PITFALLS

- Yahoo returns 429 under load. the fetcher retries with backoff; if it gives up, that is a gap.
- pre/post-market prices appear in `meta`. use the daily `close` series for consistency.
- unadjusted closes around a split or dividend show a fake gap. a 1-day move over ~40% with no news
  means suspect a corporate action before reporting a crash.
- thinly traded tickers produce meaningless z-scores. state the average volume — under ~100k/day and
  the statistics are unreliable, so say so.
