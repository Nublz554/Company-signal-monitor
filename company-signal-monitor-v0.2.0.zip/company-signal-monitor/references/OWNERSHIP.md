# OWNERSHIP.md — who owns who, and who owns this

two directions. **down**: what this company owns. **up**: who owns this company. plus, closest in:
the people with the keys.

## DOWN — what the company owns

- **10-K Exhibit 21 ("Subsidiaries of the Registrant")** is the authoritative parent→child map, and
  it is free in EDGAR. it lists subsidiary names and jurisdictions of incorporation.
  ```
  curl -s -H "User-Agent: CompanySignalMonitor <contact>" \
    "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=<cik>&type=10-K&dateb=&owner=include&count=5"
  ```
  then open the filing index and read Exhibit 21.1.
- **the company's own 13D/13G filings** show what *it* holds in others. search EDGAR full-text for
  the filer's CIK rather than its name — names change, CIKs do not.
- **EDGAR full-text search on brand variants** — `"<Subject> Holdings"`, `"<Subject> Capital"`,
  `"<Subject> International"` — surfaces subsidiaries that file in their own right.

**Exhibit 21 is frequently abbreviated** ("and other subsidiaries," "certain subsidiaries omitted").
Record that as a gap. An incomplete subsidiary map is a normal finding; pretending it's complete is not.

## UP — who owns this

| form | what it gives | cadence |
|---|---|---|
| **SC 13D** | anyone crossing 5% **with intent** (activist, control) | within days of crossing |
| **SC 13G** | anyone crossing 5% **passively** | 45 days after quarter end |
| **13F-HR** | every manager over $100M AUM: positions and sizes | quarterly |
| **DEF 14A** | the proxy: full ownership table, comp, related-party deals, board interlocks | annual |
| **Form 3** | an insider's opening position | on becoming an insider |
| **Form 4** | every insider change | within 2 business days |
| **Form 144** | notice of intent to sell restricted stock | before the sale |

measured on Apple's last 1000 filings: **601 Form 4s, 22 SC 13G/As, 12 proxies, 11 Form 3s.**

### the three ownership signals that actually carry

1. **13D versus 13G is intent, not size.** both are 5% crossings; a 13D is someone arriving to change
   things, a 13G is someone parking money. a 13D lands within days — it is the earliest public signal
   in this dataset.
2. **the 13F quarter-over-quarter DIFF.** the level is uninteresting; the change is the finding. new
   positions, closed positions, and size changes by a named manager.
3. **insider cluster.** three or more insiders transacting in the same direction inside one 30-day
   window. one sale is noise. a cluster is a signal. a cluster of **buys** is the most documented edge
   in EDGAR; a cluster of sells during a buyback is a different and unpleasant finding.

## SOURCE

```
curl -s -H "User-Agent: CompanySignalMonitor <contact>" \
  "https://data.sec.gov/submissions/CIK##########.json"     # find the forms
```
then the filing index, then the XML for Form 3/4 (`ownershipDocument`) or the 13F information table.
EDGAR full-text: `https://efts.sec.gov/LATEST/search-index?q=<terms>&forms=<FORM>`.

## DONE WHEN

- subsidiary list extracted, or the exhibit's abbreviation recorded as a gap
- every >5% holder named with form type and filing date
- 13F QoQ change computed for at least the largest institutional holders, or a stated gap
- insider activity classified: cluster / routine / none, with the window used
- the proxy read for related-party transactions and board interlocks

## PITFALLS

- **13F is 45 days stale and long-only.** it describes a position that may already be gone, and it
  cannot see shorts.
- **13G/A amendments are routine.** a filing is not new intent.
- **ETF and index holdings swamp the signal** for large caps. a 13F line that reflects an index fund is
  not a conviction bet — check whether the manager's other positions look like an index.
- **street names.** shares are held in nominee ("Cede & Co") names at the depository; the beneficial
  owner may be invisible.
- **multiple share classes** split ownership tables in ways that hide control. check `dei:EntityCommonStockSharesOutstanding`
  per class before computing a percentage.
- **a Form 4 is not always meaningful.** scheduled 10b5-1 sales, option exercises and tax withholding
  all appear as sells. read the transaction code and the footnote before calling anything a signal.
- **never assemble a personal profile.** these forms name individuals *as holders and officers of the
  company*. report the transaction and the role. no addresses, no family, no outside interests.
