# SATA.md — site imagery, from orbit

reading a company's **physical plant** out of the sky. a factory is a machine that leaves a mark on
the ground, and the mark changes before the press release does.

## THE LINE — sites, not people

- targets are **industrial, commercial, and logistics sites of the subject company**: plants,
  warehouses, distribution centres, ports, rail yards, staging lots, construction sites, offices.
- **never** a residence, a neighbourhood block, a school, a person's route, a person's commute, or
  any imagery whose purpose is "who is where." follow-the-money means the *money's* footprint — the
  site, the yard, the container stack — not a human being's day.
- if a task asks for the other kind, return `coverage: failed` with the out-of-scope gap and stop.

## WHAT FREE IMAGERY CAN AND CANNOT DO — read this before writing a finding

| source | GSD | revisit | key | notes |
|---|---|---|---|---|
| Sentinel-2 L2A | **10 m** | ~5 days | none | ESA, free, 2015→today. the workhorse. |
| Sentinel-1 SAR | 10 m | ~12 days | none | sees through cloud and dark. change detection. |
| Landsat 8/9 | 30 m | 16 days | none | long archive back to 2013 (L8). |
| Google Earth Pro | sub-metre | **years** | manual | best detail, but the date is often 1-3 years old. |

**a car is about 4.5 m long. sentinel-2 pixels are 10 m. you CANNOT count cars.** not at this
resolution, on this budget, ever. anyone doing it is inventing numbers. say this plainly rather than
delivering a confident fake.

**what 10 m CAN see:** building footprints appearing or vanishing · new construction pads and
graded earth · demolition · **area** change in a parking lot or yard (not individual vehicles) ·
container/shipping-yards at coarse volume · rail car rakes · crane presence · building-scale
structural damage, fire scars, roof collapse · site expansion or contraction between two dated
acquisitions.

**what needs the manual tier:** anything sub-metre. that means Google Earth Pro or Copernicus
Browser, read by hand, with the date captured.

## THE TWO-DATED-IMAGE RULE

A finding requires **two images, with acquisition dates, of the same site.** One image is not a
change — it is a snapshot, and a snapshot can be read to say anything.

Every imagery finding carries:
1. `before` date + scene ID or source
2. `after` date + scene ID or source
3. GSD of both
4. what changed, described at a scale the GSD can actually resolve

If you cannot get a matching pair, the finding is `CLAIMED` at best, and usually it belongs in
`gaps` as "single acquisition only."

## THE LOT-DIRECTION TRAP — the single most common way this analysis is wrong

"the lot is fuller, so sales are down" **is not a signal, it is a guess wearing a signal's coat.**
A fuller lot means opposite things depending on *which* lot:

| lot | fuller means | read |
|---|---|---|
| finished-vehicle storage | unsold inventory piling up | **bearish** |
| employee parking | extra shifts running | **bullish** |
| parts / raw-material yard | stockpiling ahead of a run | bullish, or a supply hedge |
| outbound truck queue | throughput up | **bullish** |
| inbound truck queue | supply arriving, or a bottleneck | ambiguous — say so |
| supplier overflow lot | capacity strain | ambiguous |

So: **name the lot, then state the direction, then state what would flip it.** Never report
"parking lot fuller, stock down" without identifying the lot and why that direction follows.

## PROCEDURE

### 1. resolve the site
Get the facility's coordinates from the company's own filings or property records — an address in a
10-K, a plant location in a press release, an EPA/permit filing. Record lat/lon and a bounding box.
Done when the bbox encloses the plant and not the town.

### 2. find a dated pair
Keyless STAC search, Earth Search (AWS), no account:

```
curl -s -X POST "https://earth-search.aws.element84.com/v1/search" \
  -H "Content-Type: application/json" \
  -d '{"collections":["sentinel-2-l2a"],
       "bbox":[-121.96,37.48,-121.93,37.50],
       "limit":30,
       "query":{"eo:cloud_cover":{"lt":10}}}'
```

Returns features with `properties.datetime`, `properties.eo:cloud_cover`, `properties.gsd`, and an
`assets` map containing `visual` (true-colour COG), `thumbnail`, `scl` (scene classification — use
`scl` to mask cloud and shadow properly), and the raw bands.

Pick the scene **closest to your comparison date** on each side, cloud cover as the tiebreak — not the
globally lowest-cloud scene. Chasing 0% cloud pulls in a scene many months away and turns seasonality
into a "change." Done when you have two scene IDs with dates and cloud covers under 10%.

### 3. pull the visual and compare — ONE LOOK, ONE COMPARISON

With `rasterio` present, `scripts/site_imagery.py` crops the `visual` COG to the site bbox and
window-reads just that area — COGs support HTTP range reads, so you never download a 110 km tile:

```
python scripts/site_imagery.py --name "Tesla Fremont" --lat 37.4927 --lon -121.9447 \
    --half-km 1.2 --split 2026-06-01 --out "$LOCALAPPDATA/Temp/csm-sata-tesla"
```

It writes `before.png`, `after.png`, and **`composite.png`** — the two dates stitched side by side
with a red divider. **Compare the COMPOSITE, in a single `vision_analyze` call.**

This is not a convenience, it is the honesty mechanism. Measured on this skill: given the two crops
in *separate* calls, the vision pass described both years' main lot as "very full" (70-80% in 2025,
65-75% in 2026 — i.e. **no change**) and then volunteered that "the core production complex is
visibly larger than the original footprint, with new construction added to the south and east." It
had no reference image and could not know that. It invented a difference because it was asked to
describe. A single side-by-side frame forces *relative* judgement instead.

Then, for each feature, return a verdict — **changed / unchanged / cannot determine** — and name the
pixels: a change smaller than about three pixels across (30 m) is at the edge of what 10 m can
resolve. Any "new construction" claim needs a third source (a permit filing, an 8-K, a press release)
before it counts as more than a picture.

Done when every stated change is visible in the composite at a scale the GSD resolves, and
everything else is filed under cannot-determine.

### 4. report at the resolution you actually have
State the GSD in the finding. A change you can only see because you squinted is not a finding.
Done when every claim is either "visible at 10 m" or explicitly downgraded to `CLAIMED` or `gaps`.

## DONE WHEN

- site coordinates and bbox recorded, sourced from a filing or property record
- a dated pair with scene IDs, or an explicit gap saying no pair was obtainable
- GSD stated for each image
- lot direction stated with the lot named
- a "what would change this" line — e.g. "a third acquisition showing the yard draining"

## PITFALLS

- **seasonal confounds.** snow, foliage, harvest, and shadow make the same site look transformed.
  compare the same month across years, not march against september.
- **holiday and shutdown effects** produce real lot changes that mean nothing about demand. check the
  calendar before calling an empty lot a slowdown.
- **imagery dates are not publication dates.** a scene from february tells you about february. never
  present an old acquisition as current.
- **cloud and haze** — filter on `eo:cloud_cover` AND check `scl`, because a cloudy pixel still
  counts as low cloud cover if it sits at the tile edge.
- **tile seams.** sentinel-2 tiles are 110 km; a site near a seam needs scenes from both tiles.
- **10 m is coarse.** an area change smaller than roughly three pixels across (30 m) is noise.
  declare it as such.
- **Google Earth Pro's date is often years old** and its terms restrict automated extraction. read
  it by eye and cite the date the UI shows, or don't cite it.
- **do not narrate intent from a shape.** "they are expanding" needs a pad and a building; a graded
  field with no construction in the next acquisition is a graded field.
