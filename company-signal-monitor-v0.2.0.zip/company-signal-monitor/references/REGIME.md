# REGIME.md — is this the company, or the whole market?

the question this module answers, and the one people skip: **is the move about this company or about
everything it sits next to?** get that wrong and you attribute a factor event to a business decision.

## THE CLUSTER TEST — run this before any price-based finding

pull the same window for **3-5 peers plus a broad benchmark**. then compare peak dates.

- **peers peaking on the SAME DATE as the subject and the benchmark** = a factor or market event.
  do not attribute it to the company. say "sector-wide" and stop.
- **the subject falling while its peers and the benchmark hold** = idiosyncratic. that is a company
  finding, and now it's worth explaining.
- **the subject rising while everything falls** = also idiosyncratic, and also worth explaining.

*Measured example (2026-11-03).* NVDA, SPY and QQQ all peaked **2026-10-06**; MSFT peaked 10-13; SMH
and AMD 10-06. From-peak drawdowns: NVDA -15.5%, AMD -28.1%, SMH -24.0%, QQQ -10.3%, **SPY -3.5%**.
The cluster says: a market-wide top, with semis bearing multiples of the index's damage. The company
story is the *dispersion*, not the decline.

## METRICS THAT MATTER

| metric | why it matters |
|---|---|
| drawdown from peak | the only honest measure of "money got wiped" |
| **peak date** | the cluster test lives here |
| 1y return | separates "gave back a run" from "collapsed" |
| realized vol 30d | regime: expanding or calming |
| relative perf vs benchmark | isolates the company from the market |
| span of peers' peak dates | a wide spread = idiosyncratic; a single date = a factor |

**"from peak" and "over the year" are different questions and both must be reported.** a name down
15% from its high but flat on the year has surrendered a run. a name down 15% from its high and down
60% on the year is in distress. same headline drawdown, opposite situations.

## CROWDING AND BUBBLE DISCIPLINE

Crowded-trade unwind signature, all three together:
1. realized vol expanding sharply (30-60%+ annualized on a large cap is a warning, not a feature)
2. peer correlations rising — names moving as one instead of on their own news
3. news volume spiking while price falls

Call it a **crowded trade unwinding**, not a bubble popping. "Bubble" is a story about the future;
crowding is a measurement about the present. Report what is measured.

**Never call a top or a bottom.** this module describes the regime the company is standing in. it does
not time it.

## SOURCES

- price and vol: Yahoo chart API, `range=2y&interval=1d` — `range=2y` so the peak is actually inside
  the window. a 1y window starting *after* the peak hides the peak and inverts the whole analysis.
- peer set: the subject's own filings and its 10-K competition section name its comparables. use
  those, not a set you picked because it makes the graph look good.
- mania volume: GDELT `timelinevol` for the subject and for the sector phrase.

## DONE WHEN

- peer set chosen and justified, with its source
- peak date and drawdown reported for subject, each peer, and the benchmark
- the cluster test stated explicitly: factor event, or idiosyncratic
- both from-peak and 1y returns stated
- no top/bottom call anywhere

## PITFALLS

- **survivorship and cherry-picking.** choosing peers that flatter a thesis is the easiest way to
  fake this module. use the company's own named competitors.
- **mismatched windows.** comparing one name's 2y peak against another's 1y peak is meaningless.
- **a US market holiday** puts one name's "peak" a day off. check the calendar before reading a
  one-day peak discrepancy as a signal.
- **small peer sets lie.** three peers can all be idiosyncratic together. four or more, plus a
  benchmark.
- **vol is not direction.** high vol says the regime is unstable; it says nothing about which way.
- **do not narrate macro.** if the benchmark moved, report the benchmark. do not explain it with a
  story you did not measure.
